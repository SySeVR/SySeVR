  void CVE_2012_3964_VULN_ClearTextRuns() {
    ClearTextRun(nsnull, nsTextFrame::eInflated);
    ClearTextRun(nsnull, nsTextFrame::eNotInflated);
  }
